require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const langdetect = require('langdetect');
const { CohereClient } = require('cohere-ai');

const COHERE_API_KEY = process.env.COHERE_API_KEY;
if (!COHERE_API_KEY) {
  console.error('Missing Cohere API Key');
  process.exit(1);
}

const cohere = new CohereClient({
  token: COHERE_API_KEY,
});

const app = express();
app.use(cors());
const PORT = 3001;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const SUPPORTED_LANGUAGES = ['en', 'fr', 'de', 'es' ];

const summaryLengths = {
  short: { length: 'short' },
  medium: { length: 'medium' },
  large: { length: 'long' }
};

// Function to normalize language codes
const normalizeLanguageCode = (code) => {
  const normalizedCode = code.toLowerCase().split('-')[0];
  return SUPPORTED_LANGUAGES.includes(normalizedCode) ? normalizedCode : null;
};

// Function to summarize text using Cohere API
const summarizeText = async (text, summaryType) => {
  try {
    console.log(`Summarizing text with ${summaryType} length...`);
    const response = await cohere.summarize({
      text: text,
      length: summaryLengths[summaryType].length,
      format: 'paragraph',
      model: 'summarize-xlarge',
      additional_command: 'Make sure the summary captures the main points accurately.'
    });
    console.log('Summary completed:', response.summary.substring(0, 50) + '...');
    return response.summary;
  } catch (error) {
    console.error('Error in summarizeText:', error);
    throw new Error('Failed to summarize the text. Please try again.');
  }
};

// Updated translateText function
const translateText = async (text, sourceLanguage, targetLanguage) => {
  try {
    console.log(`Translating from ${sourceLanguage} to ${targetLanguage}...`);
    const response = await cohere.generate({
      model: 'command-nightly',
      prompt: `Translate the following text from ${sourceLanguage} to ${targetLanguage}. Only provide the translation, do not include any other text or the original text:

Original (${sourceLanguage}): ${text}

Translation (${targetLanguage}):`,
      max_tokens: 500,
      temperature: 0.3,
      k: 0,
      stop_sequences: ["\n\n", "\n"],
      return_likelihoods: 'NONE'
    });
    const translatedText = response.generations[0].text.trim();
    console.log('Translation completed:', translatedText.substring(0, 50) + '...');
    
    // Check if the translated text matches the target language
    const detectedTranslationLang = normalizeLanguageCode(langdetect.detect(translatedText)[0].lang);
    if (detectedTranslationLang !== targetLanguage) {
      console.error(`Translation error: Expected ${targetLanguage}, but got ${detectedTranslationLang}`);
      throw new Error('Translation produced unexpected language output.');
    }
    
    return translatedText;
  } catch (error) {
    console.error('Error in translateText:', error);
    throw new Error('Failed to translate the text. Please try again.');
  }
};

// Endpoint to summarize and conditionally translate text
app.post('/summarize-and-translate', async (req, res) => {
  const { text, targetLanguage, summaryLength } = req.body;

  console.log('Received request:', { text: text.substring(0, 50) + '...', targetLanguage, summaryLength });

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Invalid input. Please provide valid text.' });
  }

  const detectedLanguage = normalizeLanguageCode(langdetect.detect(text)[0].lang);
  const normalizedTargetLanguage = normalizeLanguageCode(targetLanguage);

  console.log(`Detected Language: ${detectedLanguage}, Target Language: ${normalizedTargetLanguage}`);

  if (!detectedLanguage) {
    return res.status(400).json({ error: 'Unsupported or undetected language' });
  }

  if (!summaryLength || !summaryLengths[summaryLength]) {
    return res.status(400).json({ error: 'Invalid summary length. Choose short, medium, or large.' });
  }

  try {
    let summarizedText = await summarizeText(text, summaryLength);

    if (normalizedTargetLanguage && normalizedTargetLanguage !== detectedLanguage) {
      console.log(`Translating from ${detectedLanguage} to ${normalizedTargetLanguage}...`);
      summarizedText = await translateText(summarizedText, detectedLanguage, normalizedTargetLanguage);
    } else {
      console.log('No translation needed or requested.');
    }

    return res.json({ summarizedText });
  } catch (e) {
    console.error('Error in /summarize-and-translate:', e.message);
    return res.status(500).json({ error: e.message });
  }
});

// Fallback for undefined routes
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port: ${PORT}`);
});