Text Summarizer: summarizes text in 3 responses using Generative AI models
