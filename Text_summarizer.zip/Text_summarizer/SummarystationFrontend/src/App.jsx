import { useEffect, useState } from 'react';
import './App.css';
import Navbar from './components/Navbar';
import SplitView from './components/SplitView';
import TextComponent from './components/TextComponent';
import SummaryComponent from './components/SummaryComponent';
import Footer from './components/Footer';
import axios from 'axios';

function App() {
  const [text, setText] = useState("");
  const [summaryLength, setSummaryLength] = useState("short");
  const [targetLanguage, setTargetLanguage] = useState("en");
  const [leftWeight, setLeftWeight] = useState(1); 
  const [rightWeight, setRightWeight] = useState(0); 
  const [showSummary, setShowSummary] = useState(false); 
  const [summarizedText, setSummarizedText] = useState("");
  const [error, setError] = useState(''); 
  const [loading, setLoading] = useState(false);

  const summarize = async () => {
    setError(''); 
    setSummarizedText('')
    if (!text.trim()) {
      setError('Please provide valid input text for summarization');
      return;
    }
    const payload = {
      text: text.trim(),
      targetLanguage,
      summaryLength
    }
    try{
      setLoading(true)
      const res = await axios.post("http://localhost:3001/summarize-and-translate", payload);
      console.log(res, "res")
      if(res.status !== 200){
        setError(res.message);
      }
      if (res.data.summarizedText) {
        setSummarizedText(res.data.summarizedText);
      }
      setLoading(false)
    }catch(e){
      setError(e.message);
      console.log(e);
      setLoading(false)
    }
  }




  const handleSummarize = async () => {
   if(text){
    setShowSummary(true); 
    setLeftWeight(2); 
    setRightWeight(1); 
    await summarize()
   }else{
    setError('Please provide valid input text for summarization');
      return;
   }
  };

  const handleClose = () => {
    setShowSummary(false); 
    setLeftWeight(1); 
    setRightWeight(0); 
  }

  // useEffect(() => {
  //   if (error) {
  //     const timer = setTimeout(() => {
  //       setError('');
  //     }, 5000);

  //     return () => clearTimeout(timer); 
  //   }
  // }, [error]);

  return (
    <div className="flex flex-col min-h-screen justify-between">
      <Navbar />
      <div className="flex-grow">
        <SplitView leftWeight={leftWeight} rightWeight={rightWeight}>
          <TextComponent
            setText={setText}
            text={text}
            setSummaryLength={setSummaryLength}
            summaryLength={summaryLength}
            setTargetLanguage={setTargetLanguage}
            targetLanguage={targetLanguage}
            onSummarize={handleSummarize} 
            loading={loading}
          />
          {showSummary && ( 
            <SummaryComponent
            error={error}
              summarizedText={summarizedText}
              showSummary={showSummary}
              handleClose={handleClose}
              loading={loading}
            />
          )}
        </SplitView>
      </div>
      <Footer />
    </div>
  );
}

export default App;
