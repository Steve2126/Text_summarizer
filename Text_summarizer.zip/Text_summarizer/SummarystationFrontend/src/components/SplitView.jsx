import React from 'react'

const SplitView = ({ children, leftWeight, rightWeight }) => {
    const [left, right] = children;
    
    return (
      <div className="main-container flex p-3">
        <div className={`flex-${leftWeight}`}>
          {left}
        </div>
        <div className={`flex-${rightWeight}`}>
          {right}
        </div>
      </div>
    );
  };

export default SplitView