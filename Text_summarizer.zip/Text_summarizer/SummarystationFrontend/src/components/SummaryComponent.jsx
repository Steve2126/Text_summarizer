import React from 'react';
import { Button } from './ui/button';
import { AiOutlineLoading3Quarters } from "react-icons/ai";
import AlertDestructive from './AlertDestructive';


const SummaryComponent = ({ handleClose, summarizedText, loading, error }) => {
    const onClose = () => {
        handleClose();
    };

    return (
        <div className="flex flex-col justify-between backdrop-blur-sm rounded-2xl shadow-2xl bg-white h-full">
            <div className="header px-4 py-3 border-b bg-gray-200 rounded-t-2xl">
                <h2 className="text-sm font-medium text-gray-700">Summary</h2>
            </div>
            <div className="body flex-grow p-4 overflow-y-auto">
                {loading ? (
                    <div className='flex items-center justify-center h-full' >
                        <AiOutlineLoading3Quarters className="animate-spin text-6xl" />
                    </div>
                ) : (
                    error ? <AlertDestructive error={error} />: <div>{summarizedText}</div>
                )}
            </div>
            <div className="px-4 py-3 border-t bg-gray-50 flex justify-end rounded-b-2xl">
                <Button onClick={onClose} variant="outline">
                    Close
                </Button>
            </div>
        </div>
    );
};

export default SummaryComponent;
