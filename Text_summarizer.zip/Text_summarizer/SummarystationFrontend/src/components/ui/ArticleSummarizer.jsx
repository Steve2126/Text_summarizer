import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { FileText } from "lucide-react";

// Layout component
const Layout = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <FileText className="h-6 w-6 text-blue-600" />
              <h1 className="ml-2 text-xl font-semibold text-gray-900">Articles Summarizer</h1>
            </div>
            <Button variant="ghost">About me →</Button>
          </div>
        </div>
      </header>
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
};

// Main component
export default function ArticleSummarizer() {
  const [text, setText] = useState("");
  const [summaryLength, setSummaryLength] = useState([5]);

  return (
    <Layout>
      <div className="space-y-6" style={{width: "100vw"}}>
        {/* Summary Length Slider */}
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium min-w-[120px]">Summary Length</span>
          <div className="flex-1 flex items-center gap-4">
            <Slider
              max={500}
              min={1}
              step={1}
              value={summaryLength}
              onValueChange={setSummaryLength}
              className="flex-1"
            />
            <span className="w-12 text-center bg-white border rounded-md py-1 text-sm">
              {summaryLength}
            </span>
          </div>
        </div>

        {/* Two Columns Layout */}
        <div className="w-full h-full grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Input Area */}
          <div className="border rounded-lg bg-white h-full">
            <div className="px-4 py-3 border-b bg-gray-50">
              <h2 className="text-sm font-medium text-gray-700">Paste Text</h2>
            </div>
            <div className="p-4">
              <textarea
                placeholder="Enter the text you want to summarize (up to 10,000 words)..."
                className="min-h-[200px] w-full border-0 focus-visible:ring-0 p-0 resize-none"
                value={text}
                onChange={(e) => setText(e.target.value)}
                maxLength={50000} // Assuming each word is ~5 characters
              />
            </div>
            <div className="px-4 py-3 border-t bg-gray-50 flex justify-between">
              <Button variant="outline" onClick={() => setText("")}>
                Clear
              </Button>
              <Button>
                Summarize
              </Button>
            </div>
          </div>

          {/* Output Area */}
          <div className="border rounded-lg bg-white h-full">
            <div className="px-4 py-3 border-b bg-gray-50">
              <h2 className="text-sm font-medium text-gray-700">Summary</h2>
            </div>
            <div className="p-4">
              <textarea
                readOnly
                placeholder="Summary will appear here..."
                className="min-h-[200px] w-full border-0 focus-visible:ring-0 p-0 resize-none"
              />
            </div>
            <div className="px-4 py-3 border-t bg-gray-50 flex justify-end">
              <Button variant="outline">
                Clear
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
