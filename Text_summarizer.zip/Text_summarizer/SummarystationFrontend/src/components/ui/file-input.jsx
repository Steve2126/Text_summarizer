import React from 'react';

export const FileInput = React.forwardRef(({ onChange, accept }, ref) => {
  return (
    <div className="flex items-center">
      <input
        type="file"
        accept={accept}
        onChange={onChange}
        ref={ref}
        className="file-input"
      />
    </div>
  );
});
