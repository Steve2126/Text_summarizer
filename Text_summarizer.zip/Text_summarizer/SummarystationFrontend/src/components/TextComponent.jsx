import React, { useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { 
    Select,
    SelectTrigger,
    SelectContent,
    SelectItem,
    SelectValue 
} from '@/components/ui/select';
import { Upload, Loader2 } from 'lucide-react';

const TextComponent = ({loading, onSummarize, text, setText, summaryLength, setSummaryLength, targetLanguage, setTargetLanguage, isLoading }) => {
    const handleFileUpload = useCallback(async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        // Check file type
        const validTypes = ['text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!validTypes.includes(file.type)) {
            alert('Please upload a .txt or .doc file');
            return;
        }

        try {
            if (file.type === 'text/plain') {
                // Handle .txt files
                const text = await file.text();
                setText(text);
            } else {
                // For .doc files, you would typically need a backend service to process these
                // For now, we'll just show a message
                alert('DOC file support requires server-side processing. Only the filename will be shown.');
                setText(`File selected: ${file.name}\n\nDocument content would appear here...`);
            }
        } catch (error) {
            console.error('Error reading file:', error);
            alert('Error reading file');
        }
    }, [setText]);

    return (
        <div className="flex flex-col justify-between backdrop-blur-sm rounded-2xl shadow-2xl bg-white h-full mr-3">
            <div className="header px-4 py-3 border-b bg-gray-200 rounded-t-3xl">
                <h2 className="text-sm font-medium text-gray-700">Paste or Upload Text</h2>
            </div>
            <div className="body flex-grow flex flex-col justify-between">
                <div className="text-area h-full p-3 relative">
                    <textarea
                        placeholder="Enter the text you want to summarize (up to 10,000 words)..."
                        className="min-h-[200px] p-3 h-full w-full border-0 focus-visible:ring-0 resize-none"
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        maxLength={50000}
                    />
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        {!text && (
                            <div className="bg-gray-50 rounded-lg p-6 text-center pointer-events-auto">
                                <Upload className="w-8 h-8 mb-2 mx-auto text-gray-400" />
                                <p className="text-sm text-gray-500 mb-2">Drag and drop your file here</p>
                                <p className="text-xs text-gray-400 mb-3">or</p>
                                <label className="relative cursor-pointer">
                                    <input
                                        type="file"
                                        onChange={handleFileUpload}
                                        accept=".txt,.doc,.docx"
                                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                    />
                                    <Button variant="outline" size="sm">
                                        Choose File
                                    </Button>
                                </label>
                                <p className="text-xs text-gray-400 mt-2">Supports .txt and .doc files</p>
                            </div>
                        )}
                    </div>
                </div>
                <div className="flex flex-col">
                    <div className="call-to-action flex">
                        <div className="p-4 w-1/2">
                            <label className="text-sm font-medium text-gray-700">Summary Length</label>
                            <Select value={summaryLength} onValueChange={setSummaryLength}>
                                <SelectTrigger className="mt-2 w-full">
                                    <SelectValue placeholder="Length of summary" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="short">Short</SelectItem>
                                    <SelectItem value="medium">Medium</SelectItem>
                                    <SelectItem value="large">Large</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="p-4 w-1/2">
                        <label className="text-sm font-medium text-gray-700">Target Language</label>
                        <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                            <SelectTrigger className="mt-2 w-full">
                                <SelectValue placeholder="Select language" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="en">English</SelectItem>
                                <SelectItem value="es">Spanish</SelectItem>
                                <SelectItem value="fr">French</SelectItem>
                                <SelectItem value="de">German</SelectItem>
                                <SelectItem value="zh-cn">Chinese</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    </div>
                </div>
            </div>

            <div className="footer">
                <div className="px-4 py-3 border-t bg-gray-50 flex justify-between rounded-b-3xl"> {/* Adjusted for bottom-rounded corners */}
                    <Button
                        className={`${!text ? 'opacity-50 cursor-not-allowed' : ''}`}
                        disabled={!text}
                        variant="outline"
                        onClick={() => setText("")}>
                        Clear
                    </Button>
                    <Button
                        onClick={onSummarize}
                        className={`${!text ? 'opacity-50 cursor-not-allowed' : ''}`}
                        disabled={!text}
                    >
                        {loading && (
                            <svg
                                className="animate-spin mr-2"
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            >
                                <path d="M12 2v4" />
                                <path d="m16.2 7.8 2.9-2.9" />
                                <path d="M18 12h4" />
                                <path d="m16.2 16.2 2.9 2.9" />
                                <path d="M12 18v4" />
                                <path d="m4.9 19.1 2.9-2.9" />
                                <path d="M2 12h4" />
                                <path d="m4.9 4.9 2.9 2.9" />
                            </svg>
                        )}
                        Summarize
                    </Button>

                </div>
            </div>
        </div>
    );
};

export default TextComponent;