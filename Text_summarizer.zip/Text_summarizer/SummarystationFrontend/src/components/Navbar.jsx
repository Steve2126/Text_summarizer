import { FileText } from 'lucide-react'
import React from 'react'

const Navbar = () => {
  return (
    <nav className="bg-gray-800 p-4">
      <div className="container mx-auto flex items-center justify-center">
        <FileText className="h-6 w-6 text-white" />
        <h1 className="text-white text-2xl pl-4 nav-heading">SUMMARY STATION</h1>
      </div>
    </nav>
  )
}

export default Navbar